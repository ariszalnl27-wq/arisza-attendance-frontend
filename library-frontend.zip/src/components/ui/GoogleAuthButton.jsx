import { useGoogleLogin } from '@react-oauth/google'
import { googleAuth } from '../../features/auth/api/authApi'
import { useAuthStore } from '../../store/authStore'
import { getErrorMsg } from '../../lib/utils'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import Spinner from './Spinner'

export default function GoogleAuthButton({ label = 'Lanjutkan dengan Google' }) {
  const navigate  = useNavigate()
  const setAuth   = useAuthStore((s) => s.setAuth)
  const [loading, setLoading] = useState(false)

  const handleSuccess = async (tokenResponse) => {
    setLoading(true)
    try {
      const res = await googleAuth(tokenResponse.access_token)
      const { user, accessToken, refreshToken } = res.data.data
      setAuth(user, accessToken, refreshToken)
      toast.success(`Selamat datang, ${user.name}.`)
      navigate(user.role === 'admin' ? '/admin/dashboard' : '/dashboard')
    } catch (err) {
      toast.error(getErrorMsg(err))
    } finally {
      setLoading(false)
    }
  }

  const login = useGoogleLogin({
    onSuccess: handleSuccess,
    onError: () => toast.error('Login Google gagal. Coba lagi.'),
    flow: 'implicit',   // gunakan popup flow, bukan redirect
  })

  return (
    <button
      type="button"
      onClick={() => login()}
      disabled={loading}
      className="w-full flex items-center justify-center gap-3 border border-stone-200 bg-white
                 rounded px-4 py-2.5 text-sm text-stone-700 font-medium
                 hover:bg-stone-50 hover:border-stone-300 transition-all duration-150
                 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {loading ? (
        <Spinner size={16} className="text-stone-400" />
      ) : (
        <GoogleIcon />
      )}
      {loading ? 'Menghubungkan...' : label}
    </button>
  )
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z" fill="#34A853"/>
      <path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
    </svg>
  )
}
